 README.md

Study Group Finder

- Përshkrimi i projektit

Study Group Finder është një aplikacion i krijuar me Flutter që ndihmon nxënësit të gjejnë grupe për mësim dhe të bashkëpunojnë me nxënës të tjerë.

## Teknologjitë e përdorura

* Flutter
* Dart
* Supabase
* HTTP

## Funksionet e aplikacionit

* Shfaqja e grupeve të mësimit.
* Kërkimi i grupeve sipas lëndës.
* Krijimi i grupeve të reja.
* Shfaqja e vendit dhe kohës së takimit.
* Faqja e profilit.
* Ndryshimi ndërmjet temës së çelët dhe të errët.

## Struktura e projektit

* `lib/main.dart` – kodi kryesor i aplikacionit.
* `pubspec.yaml` – konfigurimi i projektit dhe paketat e përdorura.
* `Day5_SQL.txt` – komandat SQL për databazën Supabase.
* `screenshot1.png` – pamja kryesore e aplikacionit.
* `screenshot2.png` – pamja e krijimit të grupit.
* `screenshot3.png` – pamja e grupeve ose profilit.

## Si të ekzekutohet projekti

1. Hap projektin në FlutLab.
2. Kontrollo konfigurimin e `pubspec.yaml`.
3. Ekzekuto Pub get për instalimin e paketave.
4. Kontrollo konfigurimin e Supabase.
5. Shtyp Run për ta ekzekutuar aplikacionin.

## Siguria

Aplikacioni është përgatitur për t'u lidhur me Supabase. Për përdorimin e databazës duhet të konfigurohen tabelat dhe politikat RLS. Çelësat sekretë nuk duhet të vendosen në aplikacionin klient.

## Përfundimi

Study Group Finder synon ta bëjë më të lehtë organizimin e grupeve të mësimit, bashkëpunimin dhe ndarjen e njohurive ndërmjet nxënësve. Projekti mund të zgjerohet me regjistrimin e përdoruesve dhe ruajtjen e grupeve në databazë.
